"""Validate the profile and select a matching certificate without logging secrets."""
import copy
import datetime
import fnmatch
import hashlib
import os
from pathlib import Path
import plistlib
import re


def prepare(profile, identities, bundle_id, now=None):
    now = now or datetime.datetime.now(datetime.timezone.utc)
    expiry = profile.get('ExpirationDate')
    if not isinstance(expiry, datetime.datetime):
        raise ValueError('Provisioning profile has no expiration date.')
    if expiry.tzinfo is None:
        expiry = expiry.replace(tzinfo=datetime.timezone.utc)
    if expiry <= now:
        raise ValueError('Provisioning profile has expired.')
    if 'iOS' not in profile.get('Platform', []):
        raise ValueError('An iOS provisioning profile is required.')
    if not (profile.get('ProvisionedDevices') or profile.get('ProvisionsAllDevices')):
        raise ValueError('Use a Development, Ad Hoc, or Enterprise profile; App Store profiles cannot install directly.')
    entitlements = copy.deepcopy(profile.get('Entitlements', {}))
    team = entitlements.get('com.apple.developer.team-identifier')
    if not team or team not in profile.get('TeamIdentifier', []):
        raise ValueError('Profile team information is missing or inconsistent.')
    prefixes = profile.get('ApplicationIdentifierPrefix', [])
    allowed_id = entitlements.get('application-identifier', '')
    prefix = next((p for p in prefixes if allowed_id.startswith(p + '.')), None)
    if not prefix:
        raise ValueError('Profile App ID prefix is missing or inconsistent.')
    app_id = prefix + '.' + bundle_id
    if not fnmatch.fnmatchcase(app_id, allowed_id):
        raise ValueError('Provisioning profile does not permit the configured Bundle ID.')
    valid_identities = set(re.findall(r'^\s*\d+\) ([0-9A-Fa-f]{40})\s+"', identities, re.M))
    valid_identities = {i.upper() for i in valid_identities}
    profile_certificates = profile.get('DeveloperCertificates', [])
    identity = next((hashlib.sha1(c).hexdigest().upper() for c in profile_certificates
                     if hashlib.sha1(c).hexdigest().upper() in valid_identities), None)
    if not identity:
        raise ValueError('No valid imported signing identity matches the provisioning profile. Check the P12, its private key, and the profile.')
    entitlements['application-identifier'] = app_id
    if 'keychain-access-groups' in entitlements:
        entitlements['keychain-access-groups'] = [g.replace('*', bundle_id) for g in entitlements['keychain-access-groups']]
    # A profile wildcard is permission to choose values, not a literal app entitlement.
    # This menu requires no other wildcard capabilities.
    def wildcard(value):
        if isinstance(value, str):
            return '*' in value
        if isinstance(value, list):
            return any(wildcard(v) for v in value)
        if isinstance(value, dict):
            return any(wildcard(v) for v in value.values())
        return False
    if wildcard(entitlements):
        raise ValueError('Profile contains extra wildcard capabilities; use a profile for this app without those capabilities.')
    return identity, entitlements


def main():
    folder = Path(os.environ['SIGNING_DIR'])
    try:
        with (folder / 'profile.plist').open('rb') as f:
            profile = plistlib.load(f)
        identity, entitlements = prepare(profile, (folder / 'identities.txt').read_text(), os.environ['BUNDLE_ID'])
    except (ValueError, plistlib.InvalidFileException) as error:
        raise SystemExit(str(error)) from None
    with (folder / 'entitlements.plist').open('wb') as f:
        plistlib.dump(entitlements, f)
    with open(os.environ['GITHUB_ENV'], 'a') as f:
        f.write(f'SIGNING_IDENTITY={identity}\n')
    print('Provisioning profile validated; matching signing identity selected.')


if __name__ == '__main__':
    main()
