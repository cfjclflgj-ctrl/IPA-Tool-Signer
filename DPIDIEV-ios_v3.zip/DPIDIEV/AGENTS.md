# iOS package conventions
- Build the SwiftUI target from project.yml with XcodeGen; keep the app source unchanged when updating delivery automation.
- GitHub Actions imports user-provided signing assets only from repository Secrets into a temporary keychain, validates their compatibility, signs inside-out, verifies, then uploads only the IPA; this avoids storing private keys in source or artifacts.
- Keep provisioning validation in scripts/prepare_signing.py with offline unit tests so compatibility failures are detected without requiring Apple credentials.
