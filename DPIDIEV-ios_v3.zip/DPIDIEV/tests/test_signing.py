import copy
import datetime
import hashlib
import unittest
from scripts.prepare_signing import prepare


class SigningTests(unittest.TestCase):
    def setUp(self):
        self.now = datetime.datetime(2026, 10, 18, tzinfo=datetime.timezone.utc)
        self.cert = b'test certificate bytes, not a real credential'
        self.fingerprint = hashlib.sha1(self.cert).hexdigest().upper()
        self.identities = f'  1) {self.fingerprint} "Apple Distribution: Test"\n'
        self.profile = {
            'ExpirationDate': datetime.datetime(2027, 1, 1),
            'Platform': ['iOS'], 'ProvisionedDevices': ['test-device'],
            'TeamIdentifier': ['TESTTEAM'], 'ApplicationIdentifierPrefix': ['APPPREFIX'],
            'DeveloperCertificates': [self.cert],
            'Entitlements': {'application-identifier': 'APPPREFIX.*',
                             'com.apple.developer.team-identifier': 'TESTTEAM',
                             'keychain-access-groups': ['APPPREFIX.*'], 'get-task-allow': False},
        }

    def test_matching_identity_and_concrete_entitlements(self):
        original = copy.deepcopy(self.profile)
        identity, entitlements = prepare(self.profile, self.identities, 'com.cipherlegend.DPIDIEV', self.now)
        self.assertEqual(identity, self.fingerprint)
        self.assertEqual(entitlements['application-identifier'], 'APPPREFIX.com.cipherlegend.DPIDIEV')
        self.assertEqual(entitlements['keychain-access-groups'], ['APPPREFIX.com.cipherlegend.DPIDIEV'])
        self.assertFalse(entitlements['get-task-allow'])
        self.assertEqual(self.profile, original)

    def test_wrong_bundle_rejected(self):
        self.profile['Entitlements']['application-identifier'] = 'APPPREFIX.com.other.app'
        with self.assertRaisesRegex(ValueError, 'Bundle ID'):
            prepare(self.profile, self.identities, 'com.cipherlegend.DPIDIEV', self.now)

    def test_expired_profile_rejected(self):
        self.profile['ExpirationDate'] = datetime.datetime(2026, 1, 1)
        with self.assertRaisesRegex(ValueError, 'expired'):
            prepare(self.profile, self.identities, 'com.cipherlegend.DPIDIEV', self.now)

    def test_mismatched_certificate_rejected(self):
        with self.assertRaisesRegex(ValueError, 'No valid imported'):
            prepare(self.profile, '  0 valid identities found', 'com.cipherlegend.DPIDIEV', self.now)

    def test_app_store_profile_rejected(self):
        del self.profile['ProvisionedDevices']
        with self.assertRaisesRegex(ValueError, 'App Store'):
            prepare(self.profile, self.identities, 'com.cipherlegend.DPIDIEV', self.now)

    def test_enterprise_profile_accepted(self):
        del self.profile['ProvisionedDevices']
        self.profile['ProvisionsAllDevices'] = True
        identity, _ = prepare(self.profile, self.identities, 'com.cipherlegend.DPIDIEV', self.now)
        self.assertEqual(identity, self.fingerprint)

    def test_additional_wildcard_capability_rejected(self):
        self.profile['Entitlements']['com.apple.developer.associated-domains'] = ['*']
        with self.assertRaisesRegex(ValueError, 'wildcard'):
            prepare(self.profile, self.identities, 'com.cipherlegend.DPIDIEV', self.now)


if __name__ == '__main__':
    unittest.main()
